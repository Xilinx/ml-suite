from .pycaffe import Net, SGDSolver, NesterovSolver, AdaGradSolver, RMSPropSolver, AdaDeltaSolver, AdamSolver
from ._caffe import set_mode_cpu, set_mode_gpu, set_random_seed, set_device, Layer, get_solver, layer_type_list
from ._caffe import CAFFE_VERSION as __version__
from .proto.caffe_pb2 import TRAIN, TEST
from .classifier import Classifier
from .detector import Detector
from . import io
from .net_spec import layers, params, NetSpec, to_proto

# 2ff8d57c0d5afa55f55c53fea2bba1a8a6bf5eb216ac887dc353ca12e8ead345
