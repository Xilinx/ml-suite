import unittest

import caffe

class TestLayerTypeList(unittest.TestCase):

    def test_standard_types(self):
        #removing 'Data' from list 
        for type_name in ['Data', 'Convolution', 'InnerProduct']:
            self.assertIn(type_name, caffe.layer_type_list(),
                    '%s not in layer_type_list()' % type_name)

# 2ff8d57c0d5afa55f55c53fea2bba1a8a6bf5eb216ac887dc353ca12e8ead345
