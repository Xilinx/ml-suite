/*
 * A GEM style device manager for PCIe based OpenCL accelerators.
 *
 * Copyright (C) 2016-2018 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/pci.h>
#include <linux/platform_device.h>
#include "../xocl_drv.h"
#include "core.h"

int xocl_register_subdevs(struct xocl_dev *xd,
	struct xocl_subdev_info *sdev_info, u32 subdev_num)
{
	struct pci_dev *pdev = xd->pdev;
	u32	id;
	int	i, ret = 0;

	xd->subdev_num = subdev_num;

	/* create subdevices */
	for (i = 0; i < xd->subdev_num; i++) {
		id = sdev_info[i].id;
		xd->subdevs[id].pldev = xocl_register_subdev(xd, &sdev_info[i]);
		if (!xd->subdevs[id].pldev) {
			xocl_err(&pdev->dev, "failed to register subdev %s",
				sdev_info[i].name);
			ret = -EINVAL;
			goto failed;
		}
		/* force probe to avoid dependence issue */
		if (!device_attach(&xd->subdevs[id].pldev->dev)) {
			xocl_err(&pdev->dev, "failed to attach subdev %s",
				sdev_info[i].name);
			ret = -EIO;
			goto failed;
		}
	}

	return 0;

failed:
	for (i = ARRAY_SIZE(xd->subdevs) - 1; i >= 0; i--) {
		if (xd->subdevs[i].pldev) {
			platform_device_unregister(xd->subdevs[i].pldev);
			xd->subdevs[i].pldev = NULL;
		}
	}

	return (ret);
}

void xocl_unregister_subdevs(struct xocl_dev *xd)
{
	int	i;

	for (i = ARRAY_SIZE(xd->subdevs) - 1; i >= 0; i--) {
		if (xd->subdevs[i].pldev) {
			platform_device_unregister(xd->subdevs[i].pldev);
			xd->subdevs[i].pldev = NULL;
		}
	}

	xd->subdev_num = 0;
}
