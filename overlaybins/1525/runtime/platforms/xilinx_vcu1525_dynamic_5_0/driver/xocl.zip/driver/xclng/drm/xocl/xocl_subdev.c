/*
 * Copyright (C) 2018 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/pci.h>
#include <linux/platform_device.h>
#include "xocl_drv.h"

struct platform_device *xocl_register_subdev(struct xocl_dev *xd,
	struct xocl_subdev_info *sdev_info)
{
	struct platform_device *pldev;
	resource_size_t iostart;
	struct resource *res;
	u32 did;
	int i, retval;

	did = PCI_DEVID(xd->pdev->bus->number, xd->pdev->devfn);
	pldev = platform_device_alloc(sdev_info->name, did);
	if (!pldev) {
		xocl_err(&xd->pdev->dev, "failed to alloc device %s",
			sdev_info->name);
		retval = -ENOMEM;
		goto error;
	}

	iostart = pci_resource_start(xd->pdev, xd->bar_idx);
	
	if (sdev_info->num_res > 0) {
		res = devm_kzalloc(&pldev->dev, sizeof (*res) *
			sdev_info->num_res, GFP_KERNEL);
		if (!res) {
			xocl_err(&pldev->dev, "out of memory");
			retval = -ENOMEM;
			goto error;
		}
		memcpy(res, sdev_info->res, sizeof (*res) * sdev_info->num_res);

		for (i = 0; i < sdev_info->num_res; i++) {
			if (sdev_info->res[i].flags & IORESOURCE_MEM) {
				res[i].start += iostart;
				res[i].end += iostart;
			}
		}

		retval = platform_device_add_resources(pldev,
			res, sdev_info->num_res);
		devm_kfree(&pldev->dev, res);
		if (retval) {
			xocl_err(&pldev->dev, "failed to add res");
			goto error;
		}
	}

	pldev->dev.parent = &xd->pdev->dev;

	retval = platform_device_add(pldev);
	if (retval) {
		xocl_err(&pldev->dev, "failed to add device");
		goto error;
	}

	return pldev;

error:
	if (pldev) {
		platform_device_put(pldev);
	}
	return NULL;
}

void xocl_subdev_register(struct platform_device *pldev, u32 id, void *cb_funcs)
{
	struct xocl_dev		*xdev;

	BUG_ON(id >= XOCL_SUBDEV_NUM);
	xdev = xocl_get_xdev(pldev);
	BUG_ON(!xdev);

	xdev->subdevs[id].ops = cb_funcs;
}

#if 0
void *xocl_get_subdev_data(struct platform_device *pldev, u32 id)
{
	struct xocl_dev		*xdev;

	BUG_ON(id >= XOCL_SUBDEV_NUM);
	xdev = xocl_get_xdev(pldev);
	BUG_ON(!xdev);

	return platform_get_drvdata(xdev->subdevs[id].pldev);
}
#endif
