/*
 * Copyright (C) 2016-2018 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/pci.h>
#include "xocl_drv.h"


static int check_dev(struct device *dev, void *data)
{
	u32		id = *(u32 *)data;
	struct pci_dev	*pdev = to_pci_dev(dev);

	if (PCI_DEVID(pdev->bus->number, pdev->devfn) != id)
		return false;

	return true;
}

struct xocl_dev *xocl_get_xdev(struct platform_device *pdev)
{
	struct device *dev;

	dev = bus_find_device(&pci_bus_type, NULL, &pdev->id, check_dev);

	return dev ? pci_get_drvdata(to_pci_dev(dev)) : NULL;
}

/* INIT */
static int (*xocl_drv_reg_funcs[])(void) __initdata = {
	xocl_init_feature_rom,
	xocl_init_mm_dma,
	xocl_init_mb_scheduler,
	xocl_init_drv_user_xdma,
};

static void (*xocl_drv_unreg_funcs[])(void) = {
	xocl_fini_feature_rom,
	xocl_fini_mm_dma,
	xocl_fini_mb_scheduler,
	xocl_fini_drv_user_xdma,
};

static int __init xocl_init(void)
{
	int		ret, i;

	for (i = 0; i < ARRAY_SIZE(xocl_drv_reg_funcs); ++i) {
		ret = xocl_drv_reg_funcs[i]();
		if (ret) {
			goto failed;
		}
	}

	return 0;

failed:
	for (i--; i >= 0; i--) {
		xocl_drv_unreg_funcs[i]();
	}
	return ret;
}

static void __exit xocl_exit(void)
{
	int i;

	for (i = ARRAY_SIZE(xocl_drv_unreg_funcs) - 1; i >= 0; i--) {
		xocl_drv_unreg_funcs[i]();
	}
}

module_init(xocl_init);
module_exit(xocl_exit);

MODULE_VERSION(XOCL_DRIVER_VERSION);

MODULE_DESCRIPTION(XOCL_DRIVER_DESC);
MODULE_AUTHOR("Lizhi Hou <lizhi.hou@xilinx.com>");
MODULE_LICENSE("GPL v2");
