/*
 * A GEM style device manager for PCIe based OpenCL accelerators.
 *
 * Copyright (C) 2016-2018 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef _XOCL_PCIE_CORE_H
#define	_XOCL_PCIE_CORE_H

#define	XOCL_PCI_DEVICE(ven, did, pri)		\
	PCI_DEVICE(ven,did), .driver_data=(unsigned long)pri

int xocl_register_subdevs(struct xocl_dev *xd,
	struct xocl_subdev_info *sdev_info, u32 subdev_num);
void xocl_unregister_subdevs(struct xocl_dev *xd);
#endif
