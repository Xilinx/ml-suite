/*
 * Copyright (C) 2016-2018 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef	_XOCL_DRV_H_
#define	_XOCL_DRV_H_

#include <linux/version.h>
#if LINUX_VERSION_CODE <= KERNEL_VERSION(3,0,0)
#include <drm/drm_backport.h>
#endif
#include <drm/drmP.h>
#include <drm/drm_gem.h>
#include <drm/drm_mm.h>
#include "xclbin.h"
#include "xocl_ioctl.h"

#define	XOCL_MODULE_NAME	"xocl"
#define	XOCL_XDMA_PCI		"xocl_xdma"
#define	XOCL_FEATURE_ROM	"rom"
#define	XOCL_MM_DMA		"mm_dma"
#define	XOCL_MB_SCHEDULER	"mb_scheduler"
#define	XOCL_XVC		"xvc"

#define	XOCL_DRIVER_DESC	"Xilinx PCIe Accelerator Device Manager"
#define	XOCL_DRIVER_DATE	"20180125"
#define	XOCL_DRIVER_MAJOR	2018
#define	XOCL_DRIVER_MINOR	1
#define	XOCL_DRIVER_PATCHLEVEL	0

#define XOCL_DRIVER_VERSION                             \
	__stringify(XOCL_DRIVER_MAJOR) "."              \
	__stringify(XOCL_DRIVER_MINOR) "."              \
	__stringify(XOCL_DRIVER_PATCHLEVEL)

#define XOCL_DRIVER_VERSION_NUMBER                              \
	((XOCL_DRIVER_MAJOR)*1000 + (XOCL_DRIVER_MINOR)*100 +   \
	XOCL_DRIVER_PATCHLEVEL)

#define xocl_err(dev, fmt, args...)			\
	dev_err(dev, "%s: "fmt, __func__, ##args)
#define xocl_info(dev, fmt, args...)			\
	dev_info(dev, "%s: "fmt, __func__, ##args)
#define xocl_dbg(dev, fmt, args...)			\
	dev_dbg(dev, "%s: "fmt, __func__, ##args)

#define	XOCL_PL_TO_PCI_DEV(pldev)		\
	to_pci_dev(pldev->dev.parent)

#define XOCL_ARE_HOP 0x400000000ull

struct xocl_dev;

enum {
	XOCL_SUBDEV_FEATURE_ROM,
	XOCL_SUBDEV_MM_DMA,
	XOCL_SUBDEV_MB_SCHEDULER,
	XOCL_SUBDEV_XVC,
	XOCL_SUBDEV_NUM
};

struct xocl_subdev_info {
	u32			id;
	char			*name;
	struct resource		*res;
	int			num_res;
};

struct xocl_subdev {
	struct platform_device 		*pldev;
	void				*ops;
};

struct xocl_mem_topology {
        //TODO : check the first 4 entries - remove unneccessary ones.
        u32             bank_count;
        struct mem_data *m_data;
        u32             m_data_length; /* length of the mem_data section */
        u64             bank_size; /* in KB. Currently only fixed sizes are */
                                   /* supported. */
        u64                     size;
        struct mem_topology     *topology;
};

struct xocl_connectivity {
        u64                     size;
        struct connectivity     *connections;
};

struct xocl_layout {
        u64                     size;
        struct ip_layout        *layout;
};

struct xocl_debug_layout {
        u64                     size;
        struct debug_ip_layout  *layout;
};

struct xocl_pci_funcs {
	int (*intr_config)(struct xocl_dev *xdev, u32 intr, bool enable);
	int (*intr_register)(struct xocl_dev *xdev, u32 intr,
		irq_handler_t handler, void *arg);
	int (*dev_online)(struct xocl_dev *xdev);
	int (*dev_offline)(struct xocl_dev *xdev);
};

#define	xocl_user_interrupt_config(xdev, intr, en)	\
	xdev->pci_ops->intr_config(xdev, intr, en)
#define	xocl_user_interrupt_reg(xdev, intr, handler, arg)	\
	xdev->pci_ops->intr_register(xdev, intr, handler, arg)

struct xocl_dev	{
	struct pci_dev		*pdev;

	struct xocl_subdev	subdevs[XOCL_SUBDEV_NUM];
	u32			subdev_num;

	void * __iomem		base_addr;
	u64			bar_len;
	u32			bar_idx;

	void			*dma_handle;
	u32			max_user_intr;
	u32			start_user_intr;
	struct eventfd_ctx      **user_msix_table;
	struct mutex		user_msix_table_lock;

	bool			offline;

	struct xocl_pci_funcs	*pci_ops;

	/* memory management */
	struct drm_device		*ddev;
	/* Memory manager array, one per DDR channel */
	struct drm_mm			*mm;
	struct mutex			mm_lock;
	struct drm_xocl_mm_stat		*mm_usage_stat;
	struct mutex			stat_lock;

	struct xocl_mem_topology	topology;
        struct xocl_layout		layout;
        struct xocl_debug_layout	debug_layout;
        struct xocl_connectivity	connectivity;

	/*should be removed after mailbox is supported */
	u64			unique_id_last_bitstream;
};

#define	SUBDEV(xdev, id)	\
	(xdev->subdevs[id])

/* rom callbacks */
struct xocl_rom_funcs {
	bool (*is_unified)(struct platform_device *pdev);
	u16 (*get_ddr_channel_count)(struct platform_device *pdev);
	u64 (*get_ddr_channel_size)(struct platform_device *pdev);
	bool (*is_are)(struct platform_device *pdev);
	bool (*is_aws)(struct platform_device *pdev);
	bool (*verify_timestamp)(struct platform_device *pdev, u64 timestamp);
};
#define ROM_DEV(xdev)	\
	SUBDEV(xdev, XOCL_SUBDEV_FEATURE_ROM).pldev
#define	ROM_OPS(xdev)	\
	((struct xocl_rom_funcs *)SUBDEV(xdev, XOCL_SUBDEV_FEATURE_ROM).ops)
#define	xocl_is_unified(xdev)		\
	ROM_OPS(xdev)->is_unified(ROM_DEV(xdev))
#define	xocl_get_ddr_channel_count(xdev) \
	ROM_OPS(xdev)->get_ddr_channel_count(ROM_DEV(xdev))
#define	xocl_get_ddr_channel_size(xdev) \
	ROM_OPS(xdev)->get_ddr_channel_size(ROM_DEV(xdev))
#define	xocl_is_are(xdev)		\
	ROM_OPS(xdev)->is_are(ROM_DEV(xdev))
#define	xocl_is_aws(xdev)		\
	ROM_OPS(xdev)->is_aws(ROM_DEV(xdev))
#define	xocl_verify_timestamp(xdev, ts)	\
	ROM_OPS(xdev)->verify_timestamp(ROM_DEV(xdev), ts)

/* mm_dma callbacks */
struct xocl_mm_dma_funcs {
	ssize_t (*migrate_bo)(struct platform_device *pdev,
		struct sg_table *sgt, u32 dir, u64 paddr, u32 channel);
	int (*ac_chan)(struct platform_device *pdev, u32 dir);
	void (*rel_chan)(struct platform_device *pdev, u32 dir, u32 channel);
	int (*set_max_chan)(struct platform_device *pdev, u32 channel_count);
	u32 (*get_chan_count)(struct platform_device *pdev);
	u64 (*get_chan_stat)(struct platform_device *pdev, u32 channel,
		u32 write);
};
#define MM_DMA_DEV(xdev)	\
	SUBDEV(xdev, XOCL_SUBDEV_MM_DMA).pldev
#define	MM_DMA_OPS(xdev)	\
	((struct xocl_mm_dma_funcs *)SUBDEV(xdev, XOCL_SUBDEV_MM_DMA).ops)
#define	xocl_migrate_bo(xdev, sgt, write, paddr, chan)	\
	MM_DMA_OPS(xdev)->migrate_bo(MM_DMA_DEV(xdev), sgt, write, paddr, chan)
#define	xocl_acquire_channel(xdev, dir)		\
	MM_DMA_OPS(xdev)->ac_chan(MM_DMA_DEV(xdev), dir)
#define	xocl_release_channel(xdev, dir, chan)	\
	MM_DMA_OPS(xdev)->rel_chan(MM_DMA_DEV(xdev), dir, chan)
#define	xocl_set_max_channel(xdev, count)		\
	MM_DMA_OPS(xdev)->set_max_chan(MM_DMA_DEV(xdev), count)
#define	xocl_get_chan_count(xdev)		\
	MM_DMA_OPS(xdev)->get_chan_count(MM_DMA_DEV(xdev))
#define	xocl_get_chan_stat(xdev, chan, write)		\
	MM_DMA_OPS(xdev)->get_chan_stat(MM_DMA_DEV(xdev), chan, write)

/* mb_scheduler callbacks */
struct xocl_mb_scheduler_funcs {
	int (*add_exec_buffer)(struct platform_device *pdev, void *buf);
	int (*create_client)(struct platform_device *pdev, void **priv);
	void (*destroy_client)(struct platform_device *pdev, void **priv);
	uint (*poll_client)(struct platform_device *pdev, struct file *filp,
		poll_table *wait, void *priv);
};
#define	MB_SCHEDULER_DEV(xdev)	\
	SUBDEV(xdev, XOCL_SUBDEV_MB_SCHEDULER).pldev
#define	MB_SCHEDULER_OPS(xdev)	\
	((struct xocl_mb_scheduler_funcs *)SUBDEV(xdev, 	\
		XOCL_SUBDEV_MB_SCHEDULER).ops)
#define	xocl_exec_add_buffer(xdev, bo)		\
	MB_SCHEDULER_OPS(xdev)->add_exec_buffer(MB_SCHEDULER_DEV(xdev), bo)
#define	xocl_exec_create_client(xdev, priv)		\
	MB_SCHEDULER_OPS(xdev)->create_client(MB_SCHEDULER_DEV(xdev), priv)
#define	xocl_exec_destroy_client(xdev, priv)		\
	MB_SCHEDULER_OPS(xdev)->destroy_client(MB_SCHEDULER_DEV(xdev), priv)
#define	xocl_exec_poll_client(xdev, filp, wait, priv)		\
	MB_SCHEDULER_OPS(xdev)->poll_client(MB_SCHEDULER_DEV(xdev), filp, \
	wait, priv)

#define	XOCL_IS_DDR_USED(xdev, ddr)		\
	(xdev->topology.m_data[ddr].m_used == 1)
#define	XOCL_DDR_COUNT(xdev)			\
	((xocl_is_unified(xdev) ? xdev->topology.bank_count :	\
	xocl_get_ddr_channel_count(xdev)))

/* helper functions */
struct xocl_dev *xocl_get_xdev(struct platform_device *pdev);

/* subdev functions */
struct platform_device *xocl_register_subdev(struct xocl_dev *xd,
	struct xocl_subdev_info *sdev_info);
void xocl_subdev_register(struct platform_device *pldev, u32 id,
	void *cb_funcs);

/* ioctl functions */
int xocl_info_ioctl(struct drm_device *dev,
	void *data, struct drm_file *filp);
int xocl_execbuf_ioctl(struct drm_device *dev,
        void *data, struct drm_file *filp);
int xocl_ctx_ioctl(struct drm_device *dev, void *data,
                   struct drm_file *filp);
int xocl_user_intr_ioctl(struct drm_device *dev, void *data,
                         struct drm_file *filp);
int xocl_read_axlf_ioctl(struct drm_device *dev,
                        void *data,
                        struct drm_file *filp);

/* sysfs functions */
int xocl_init_sysfs(struct device *dev);
void xocl_fini_sysfs(struct device *dev);

/* init functions */
int __init xocl_init_drv_user_xdma(void);
void xocl_fini_drv_user_xdma(void);

int __init xocl_init_feature_rom(void);
void xocl_fini_feature_rom(void);

int __init xocl_init_mm_dma(void);
void xocl_fini_mm_dma(void);

int __init xocl_init_mb_scheduler(void);
void xocl_fini_mb_scheduler(void);

int __init xocl_init_xvc(void);
void xocl_fini_xvc(void);
#endif
