/*
 * A GEM style device manager for PCIe based OpenCL accelerators.
 *
 * Copyright (C) 2016-2018 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/pci.h>
#include <linux/aer.h>
#include "../xocl_drv.h"
#include "core.h"
#include "../lib/libxdma_api.h"
#include "../xocl_drm.h"

#define	XDMA_SCHE_INTR_START	0
#define	XDMA_USER_INTR_START	4

struct xocl_xdma_dev {
	struct xocl_dev		ocl_dev;
};

static struct resource feature_rom_res[] = {
	{
		.start	= 0xB0000,
		.end	= 0xB0FFF,
		.flags	= IORESOURCE_MEM,
	},
};

static struct resource mb_scheduler_res[] = {
	{
		.start	= 0x180000,
		.end	= 0x19FFFF,
		.flags	= IORESOURCE_MEM,
	},
	{
		.start	= XDMA_SCHE_INTR_START,
		.end	= XDMA_USER_INTR_START - 1,
		.flags	= IORESOURCE_IRQ,
	},
};

static struct xocl_subdev_info subdev_info[] =  {
	{
		XOCL_SUBDEV_FEATURE_ROM,
		XOCL_FEATURE_ROM,
		feature_rom_res,
		ARRAY_SIZE(feature_rom_res)
	},
	{
		XOCL_SUBDEV_MM_DMA,
		XOCL_MM_DMA,
		NULL,
		0
	},
	{
		XOCL_SUBDEV_MB_SCHEDULER,
		XOCL_MB_SCHEDULER,
		mb_scheduler_res,
		ARRAY_SIZE(mb_scheduler_res)
	},
};

static const struct pci_device_id pciidlist[] = {
	{ PCI_DEVICE(0x10ee, 0x4A48), },
	{ PCI_DEVICE(0x10ee, 0x4A88), },
	{ PCI_DEVICE(0x10ee, 0x4B48), },
	{ PCI_DEVICE(0x10ee, 0x4B88), },
	{ PCI_DEVICE(0x10ee, 0x6850), },
	{ PCI_DEVICE(0x10ee, 0x6890), },
	{ PCI_DEVICE(0x10ee, 0x6950), },
	{ PCI_DEVICE(0x10ee, 0x6990), },
	{ PCI_DEVICE(0x10ee, 0x6A50), },
	{ PCI_DEVICE(0x10ee, 0x6A90), },
	{ PCI_DEVICE(0x10ee, 0x6E50), },
	{ PCI_DEVICE(0x10ee, 0x6B10), },
	{ PCI_DEVICE(0x1d0f, 0x1042), },
	{ PCI_DEVICE(0x1d0f, 0xf000), },
	{ PCI_DEVICE(0x13fe, 0x0065), },
	{ 0, }
};

MODULE_DEVICE_TABLE(pci, pciidlist);

static int user_intr_config(struct xocl_dev *xdev, u32 intr, bool en)
{
	const unsigned int mask = 1 << intr;

        return en ? xdma_user_isr_enable(xdev->dma_handle, mask) :
		xdma_user_isr_disable(xdev->dma_handle, mask);
}

static int user_intr_register(struct xocl_dev *xdev, u32 intr,
	irq_handler_t handler, void *arg)
{
	const unsigned int mask = 1 << intr;
	int	ret;

	ret = xdma_user_isr_register(xdev->dma_handle, mask, handler, arg);
	return (ret);
}

static int user_dev_online(struct xocl_dev *xdev)
{
	if (xdev->offline) {
		xdma_device_online(xdev->pdev, xdev->dma_handle);
		xdev->offline = false;
	}
	xocl_info(&xdev->pdev->dev, "Device online");

	return 0;
} 

static int user_dev_offline(struct xocl_dev *xdev)
{
	if (!xdev->offline) {
		xdma_device_offline(xdev->pdev, xdev->dma_handle);
		xdev->offline = true;
	}
	xocl_info(&xdev->pdev->dev, "Device offline");

	return 0;
} 

struct xocl_pci_funcs xdma_pci_ops = {
	.intr_config = user_intr_config,
	.intr_register = user_intr_register,
	.dev_online = user_dev_online,
	.dev_offline = user_dev_offline,
};

int xocl_user_xdma_probe(struct pci_dev *pdev,
	const struct pci_device_id *ent)
{
	struct xocl_xdma_dev		*xd;
	struct xocl_dev			*ocl_dev;
	u32 channel = 0;
	int ret;

	xd = devm_kzalloc(&pdev->dev, sizeof (*xd), GFP_KERNEL);
	if (!xd) {
		xocl_err(&pdev->dev, "failed to alloc xocl_dev");
		return -ENOMEM;
	}
	/* this is used for all subdevs, bind it to device earlier */
	pci_set_drvdata(pdev, xd);

	ocl_dev = (struct xocl_dev *)xd;

	ocl_dev->pdev = pdev;

	ocl_dev->dma_handle = xdma_device_open(XOCL_XDMA_PCI, pdev,
		&ocl_dev->max_user_intr, &channel,
		&channel);
	if (ocl_dev->dma_handle == NULL) {
		xocl_err(&pdev->dev, "XDMA Device Open failed");
		ret = -ENOENT;
		goto failed;
	}

	xocl_info(&pdev->dev, "XDMA open succeed: intr: %d channel %d",
		ocl_dev->max_user_intr, channel);

	ocl_dev->start_user_intr = XDMA_USER_INTR_START;
	ocl_dev->user_msix_table = devm_kzalloc(&pdev->dev,
		sizeof (struct eventfd_ctx *) * ocl_dev->max_user_intr,
		GFP_KERNEL);
	if (!ocl_dev->user_msix_table) {
		xocl_err(&pdev->dev, "Failed to alloc mem for user intr table");
		ret = -ENOMEM;
		goto failed;
	}

	ret = xdma_get_userio(ocl_dev->dma_handle, &ocl_dev->base_addr,
		&ocl_dev->bar_len, &ocl_dev->bar_idx);
	if (ret) {
		xocl_err(&pdev->dev, "Get user bar info failed");
		goto failed;
	}
	ocl_dev->pci_ops = &xdma_pci_ops;

	ret = xocl_register_subdevs(ocl_dev, subdev_info,
		ARRAY_SIZE(subdev_info));
	if (ret) {
		xocl_err(&pdev->dev, "failed to register subdevs");
		goto failed_reg_subdevs;
	}

	ret = xocl_set_max_channel(ocl_dev, channel);
	if (ret)
		goto failed_set_channel;

	ret = xocl_drm_init(ocl_dev);
	if (ret) {
		xocl_err(&pdev->dev, "failed to init drm mm");
		goto failed_drm_init;
	}

	ret = xocl_init_sysfs(&pdev->dev);
	if (ret) {
		xocl_err(&pdev->dev, "failed to init sysfs");
		goto failed_sysfs_init;
	}

	mutex_init(&ocl_dev->user_msix_table_lock);

	return 0;

failed_sysfs_init:
	xocl_drm_fini(&xd->ocl_dev);
failed_drm_init:
failed_set_channel:
	xocl_unregister_subdevs(ocl_dev);
failed_reg_subdevs:
	xdma_device_close(pdev, ocl_dev->dma_handle);
failed:
	if (ocl_dev->user_msix_table)
		devm_kfree(&pdev->dev, ocl_dev->user_msix_table);
	devm_kfree(&pdev->dev, xd);
	pci_set_drvdata(pdev, NULL);
	return ret;
}

void xocl_user_xdma_remove(struct pci_dev *pdev)
{
	struct xocl_xdma_dev	*xd;

	xd = pci_get_drvdata(pdev);
	if (!xd) {
		xocl_err(&pdev->dev, "driver data is NULL");
		return;
	}

	xocl_fini_sysfs(&pdev->dev);
	xocl_drm_fini(&xd->ocl_dev);
	xocl_unregister_subdevs(&xd->ocl_dev);
	xdma_device_close(pdev, xd->ocl_dev.dma_handle);
	if (&xd->ocl_dev.user_msix_table)
		devm_kfree(&pdev->dev, xd->ocl_dev.user_msix_table);
	mutex_destroy(&xd->ocl_dev.user_msix_table_lock);

	devm_kfree(&pdev->dev, xd); 
	pci_set_drvdata(pdev, NULL);
}

static pci_ers_result_t user_pci_error_detected(struct pci_dev *pdev,
					    pci_channel_state_t state)
{
	switch (state) {
	case pci_channel_io_normal:
		return PCI_ERS_RESULT_CAN_RECOVER;
	case pci_channel_io_frozen:
		xocl_info(&pdev->dev, "PCI frozen state error\n");
		return PCI_ERS_RESULT_NEED_RESET;
	case pci_channel_io_perm_failure:
		xocl_info(&pdev->dev, "PCI failure state error\n");
		return PCI_ERS_RESULT_DISCONNECT;
	}
	return PCI_ERS_RESULT_NEED_RESET;
}

static pci_ers_result_t user_pci_slot_reset(struct pci_dev *pdev)
{
	xocl_info(&pdev->dev, "PCI reset slot");
	pci_restore_state(pdev);

	return PCI_ERS_RESULT_RECOVERED;
}

static void user_pci_error_resume(struct pci_dev *pdev)
{
	xocl_info(&pdev->dev, "PCI error resume");
	pci_cleanup_aer_uncorrect_error_status(pdev);
}

void xocl_reset_notify(struct pci_dev *pdev, bool prepare)
{
	struct xocl_dev	*xdev = pci_get_drvdata(pdev);

	xocl_info(&pdev->dev, "PCI reset NOTIFY, prepare %d", prepare);

	if (prepare) {
		user_dev_offline(xdev);
	} else {
		user_dev_online(xdev);
	}
}
EXPORT_SYMBOL_GPL(xocl_reset_notify);

#if LINUX_VERSION_CODE > KERNEL_VERSION(4, 13, 0)
static void user_pci_reset_prepare(struct pci_dev *pdev)
{
	xocl_reset_notify(pdev, true);
}

static void user_pci_reset_done(struct pci_dev *pdev)
{
	xocl_reset_notify(pdev, false);
}
#endif

static const struct pci_error_handlers xocl_err_handler = {
	.error_detected	= user_pci_error_detected,
	.slot_reset	= user_pci_slot_reset,
	.resume		= user_pci_error_resume,
#if LINUX_VERSION_CODE > KERNEL_VERSION(4, 13, 0)
	.reset_prepare  = user_pci_reset_prepare,
	.reset_done     = user_pci_reset_done,
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3,16,0)
	.reset_notify	= xocl_reset_notify,
#endif
};

static struct pci_driver user_xdma_driver = {
	.name = XOCL_XDMA_PCI,
	.id_table = pciidlist,
	.probe = xocl_user_xdma_probe,
	.remove = xocl_user_xdma_remove,
	.err_handler = &xocl_err_handler,
};

int __init xocl_init_drv_user_xdma(void)
{
	int ret;

	ret = pci_register_driver(&user_xdma_driver);
	if (ret) {
		goto failed;
	}

	return 0;

failed:
	return ret;
}

void xocl_fini_drv_user_xdma(void)
{
	pci_unregister_driver(&user_xdma_driver);
}
